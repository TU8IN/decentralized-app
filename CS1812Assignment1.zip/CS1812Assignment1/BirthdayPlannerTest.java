import java.io.IOException;

public class BirthdayPlannerTest {
    public static void main(String[] args) {
        testAdd();
        testGetRandomItem();
        testGetRandomItemNonExisting();
        testLoadFile();
        testLoadFileAndRetrieve();
        testCafeStore();
        testRestaurantStore();
    }

    private static void testAdd() {
        try {
            ActivityStore store = new ActivityStore();
            store.add("a", "archery");
            store.add("a", "apple bobbing");
            assert store.getRandomItem("a") != null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void testGetRandomItem() {
        try {
            ActivityStore store = new ActivityStore();
            store.add("a", "archery");
            store.add("a", "apple bobbing");
            String result = store.getRandomItem("a");
            assert result != null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void testGetRandomItemNonExisting() {
        try {
            ActivityStore store = new ActivityStore();
            String result = store.getRandomItem("nonexistent");
            assert result == null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void testLoadFile() {
        try {
            ActivityStore store = new ActivityStore("activity.txt");
            assert store.getRandomItem("a") != null;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testLoadFileAndRetrieve() {
        try {
            ActivityStore store = new ActivityStore("activity.txt");
            String result = store.getRandomItem("a");
            assert result != null;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testCafeStore() {
        try {
            CafeStore cafeStore = new CafeStore("cafe.txt");
            cafeStore.add("c", "chocolate lindor");
            assert cafeStore.getRandomItem("c") != null;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void testRestaurantStore() {
        try {
            RestaurantStore restaurantStore = new RestaurantStore("restaurant.txt");
            restaurantStore.add("n", "noodles");
            assert restaurantStore.getRandomItem("r") != null;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


