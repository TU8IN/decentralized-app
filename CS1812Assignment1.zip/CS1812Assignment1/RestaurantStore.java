import java.io.IOException;

public class RestaurantStore extends ActivityStore {

	public RestaurantStore(String fileName) throws IOException {
    	super(fileName); //parent constructor
	}

	@Override
	public String getRandomItem(String key) {
    	String randomActivity = super.getRandomItem(key);
    	if (randomActivity != null) {
        	return randomActivity + " (restaurant)";
    	}
    	return null;
	}
}


//
