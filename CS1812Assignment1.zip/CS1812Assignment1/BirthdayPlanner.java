import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BirthdayPlanner {
    private ActivityStore mainActivities;
    private CafeStore cafes;
    private RestaurantStore restaurants;
    private int maxPrefixLength;

    public BirthdayPlanner(String mainFileName, String cafeFileName, String restaurantFileName) throws IOException {
        this(1, mainFileName, cafeFileName, restaurantFileName);
    }

    public BirthdayPlanner(int maxPrefixLength, String mainFileName, String cafeFileName, String restaurantFileName) throws IOException {
        this.maxPrefixLength = maxPrefixLength;
        initializeStores(mainFileName, cafeFileName, restaurantFileName);
    }

    private void initializeStores(String mainFileName, String cafeFileName, String restaurantFileName) throws IOException {
        this.mainActivities = new ActivityStore(mainFileName, maxPrefixLength);
        this.cafes = new CafeStore(cafeFileName);
        this.restaurants = new RestaurantStore(restaurantFileName);
    }

    public List<String> generate(String input) {
        List<String> itinerary = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < input.length(); i++) {
            StringBuilder currentPrefix = new StringBuilder();

            for (int prefixLength = maxPrefixLength; prefixLength >= 1; prefixLength--) {
                if (i + prefixLength <= input.length()) {
                    currentPrefix.setLength(0);

                    for (int j = 0; j < prefixLength; j++) {
                        currentPrefix.append(input.charAt(i + j));
                    }

                    switch (i % 4) {
                        case 0:
                        case 2:
                            String mainActivity = mainActivities.getRandomItem(currentPrefix.toString());
                            if (mainActivity != null) {
                                itinerary.add(mainActivity);
                                i += prefixLength - 1;
                            }
                            break;
                        case 1:
                            String cafeActivity = cafes.getRandomItem(currentPrefix.toString());
                            if (cafeActivity != null) {
                                itinerary.add(cafeActivity + " (cafe)");
                                i += prefixLength - 1;
                            }
                            break;
                        case 3:
                            String restaurantActivity = restaurants.getRandomItem(currentPrefix.toString());
                            if (restaurantActivity != null) {
                                itinerary.add(restaurantActivity + " (restaurant)");
                                i += prefixLength - 1;
                            }
                            break;
                    }

                    if (!itinerary.isEmpty()) {
                        break;
                    }
                }
            }
        }

        return itinerary;
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Please provide an input string as the first command line argument.");
            return;
        }

        try {
            int maxPrefixLength = args.length > 1 ? Integer.parseInt(args[1]) : 1;
            BirthdayPlanner planner = new BirthdayPlanner(maxPrefixLength, "main-activities.txt", "cafes.txt", "restaurants.txt");
            List<String> itinerary = planner.generate(args[0]);
            for (String activity : itinerary) {
                System.out.println(activity);
            }
        } catch (IOException e) {
            System.out.println("Error while loading" + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Invalid maximum prefix length provided(Try to provide an integer value.");
        }
    }
}


