import java.io.IOException;
public class CafeStore extends ActivityStore {

	public CafeStore() {
    	super();
	}

	public CafeStore(String fileName) throws IOException {
    	super(fileName);
	}

	@Override
	public String getRandomItem(String key) {
    	String randomActivity = super.getRandomItem(key);
    	return randomActivity != null ? randomActivity + " (cafe)" : null;
	}
}
