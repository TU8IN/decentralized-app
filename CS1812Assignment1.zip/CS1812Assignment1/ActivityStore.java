import java.io.*;
import java.util.*;

public class ActivityStore {
    private Map<String, List<String>> store;

    public ActivityStore() {
        this.store = new HashMap<>();
    }

    public ActivityStore(String fileName) throws IOException {
        this(fileName, 1); // make default maxPrefixLength of 1
    }

    public ActivityStore(String fileName, int maxPrefixLength) throws IOException {
        this(); // default constructor


        //This willl initialize the map

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String item = line.toLowerCase();
                for (int i = 1; i <= Math.min(maxPrefixLength, item.length()); i++) {
                    String key = item.substring(0, i); // prefix extraction
                    store.computeIfAbsent(key, k -> new ArrayList<>()).add(item);
                }
            }
        } catch (IOException e) {
            throw new IOException("loading activities have failed (Try again): " + fileName, e);
        }
    }

    public void add(String key, String item) {
        key = key.toLowerCase();
        store.computeIfAbsent(key, k -> new ArrayList<>()).add(item.toLowerCase());
    }

    public String getRandomItem(String key) {
        key = key.toLowerCase();
        List<String> activities = store.get(key);

        if (activities == null || activities.isEmpty()) {
            return null;
        }

        Random random = new Random();
        int randomIndex = random.nextInt(activities.size());
        String randomActivity = activities.get(randomIndex);

        return randomActivity.replaceFirst(key, key.toUpperCase());
    }
}


